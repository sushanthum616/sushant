#include <iostream>
using namespace std;

bool logic_to_find_leapYear(int year) {
  if (year % 4 != 0) {
    return false;
  } else if (year % 100 != 0) {
    return true;
  } else if (year % 400 != 0) {
    return false;
  } else {
    return true;
  }
}

int main() {
  int year;
  cout << "Enter a year AD, for example, 1997" << endl;
  cin >> year;
  if (logic_to_find_leapYear(year)) {
    cout << year << " is a leap year" << endl;
  } else {
    cout << year << " is not a leap year" << endl;
  }
}