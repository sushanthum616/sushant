// Program Area calculates the area of a square.
// The user is prompted to enter the number of inches on each
// side. Note that "endl" in line 7 ends in the letter "l", not
// the number one.

#include <iostream>  // Include the input/output stream library
using namespace std; // Use the standard namespace

int main() {  // Start of the main function
  int inches; // Declare an integer variable to store the number of inches on a
              // side

  cout << "Enter the number of inches on a side " // Print a message asking the
                                                  // user to enter the number of
                                                  // inches on a side
       << endl; // End the line and move the cursor to the next line

  cout << "Press the return key." // Print a message asking the user to press
                                  // the return key
       << endl; // End the line and move the cursor to the next line

  cin >> inches; // Read the user's input into the variable inches

  cout << endl // End the line and move the cursor to the next line
       << "The area is " << inches * inches
       << "."   // Calculate the area by squaring the number of inches and print
                // the result
       << endl; // End the line and move the cursor to the next line

  return 0; // Return 0 indicating successful execution
} // End of the main function
